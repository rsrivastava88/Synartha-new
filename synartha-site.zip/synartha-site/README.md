# Synartha website

Static, single-file website. No build step, no framework, no dependencies to install.

## Files

| File | Purpose |
|---|---|
| `index.html` | The whole website, including the Terms & Conditions page (opens at `/?page=terms`). Fonts, logo and styles are built in. |
| `vercel.json` | Basic security headers for Vercel. |
| `robots.txt` | Lets search engines index the site. |

The only external requests are three.js r128, GSAP 3.12.5 and matter.js from cdnjs.cloudflare.com.

## Intro animation

Every device with a hardware graphics chip gets the 3D laptop intro.

| Time | What happens |
|---|---|
| 0 to 3s | Laptop rises out of the dark studio and settles, lid opening, lights coming up |
| 3 to 4.5s | Synartha logo lights up on the display |
| 4.5s | Wide screens: the real hero section switches on inside the display. Phones and portrait screens: the camera moves into the display and the site fades up |
| 5.9 to 8s | Wide screens: camera pushes into the display until the hero fills the screen |

The 2D logo reveal is used only when the device has no hardware WebGL or the 3D libraries take longer than 7 seconds to load. The intro is skipped when the visitor's system has reduced motion turned on (on Windows: Settings > Accessibility > Visual effects > Animation effects; on Mac: System Settings > Accessibility > Display > Reduce motion), when the link has a `#section`, and on the Terms page.

To see why a device got a given version, open the site with `?introdebug` and check the browser console.

To force the 3D version on a machine without a fast GPU for testing, add `?force3d` to the URL.

The laptop is modelled in code with Three.js physically based materials (brushed aluminium, glass, keys, hinge), so it lives inside `index.html` and needs no extra files. If you later commission a Blender GLB model, it can replace the procedural laptop in the `cinema()` function of the intro script.

## Before you go live

1. **Application form.** Applications are not sent anywhere yet. Create a form endpoint (Formspree, Getform, Basin or your own API that accepts a JSON POST), then in `index.html` find `SYNARTHA_CONFIG` and set `formEndpoint: 'https://...'`. Put the same URL in the form's `action=""` attribute. Until this is done, visitors see "Online applications are not connected on this page yet."
2. **Terms & Conditions text.** Search `index.html` for `data-placeholder`. Replace each placeholder block with the supplied wording and delete the `data-placeholder` attribute. While any remain, the page shows a "Legal wording pending" banner.
3. **Social icons.** The footer "Follow Synartha" row links to Instagram (instagram.com/thesynartha), Facebook (profile id 61595514071352) and X (x.com/TheSynartha), each opening in a new tab. LinkedIn shows as "coming soon" until you paste its URL into `linkedin` in `SYNARTHA_CONFIG`.
4. **Other optional links.** Fill `curriculumUrl` and `applicationPolicy` in the same block to show those links. Empty values stay hidden.
5. **Domain.** Once you have the domain, uncomment the canonical tag near the top of `index.html` and add the Sitemap line in `robots.txt`.

## Deploy on Vercel (dashboard, no coding)

1. Go to vercel.com and sign in.
2. Click **Add New → Project**.
3. Either import a GitHub repo containing these files, or drag this folder into the upload area.
4. Framework preset: **Other**. Leave build command and output directory empty.
5. Click **Deploy**. You get a preview URL ending in `.vercel.app`.

## Deploy on Vercel (command line)

```
npm i -g vercel
cd synartha-site
vercel          # preview deployment
vercel --prod   # production, after checks pass
```

## Check after deploying

1. Homepage loads, intro plays, "Skip intro" works.
2. Footer shows Privacy Policy and Terms & Conditions; each opens in a new tab.
3. `/?page=terms` loads directly and survives a refresh.
4. `/?page=terms#privacy` lands on the Privacy Policy section.
5. "Back to the site" returns to the homepage.
6. Phone numbers +91 96904 98904 and +91 96904 98916 show in the apply section, footer and Terms page.
7. Submit a test application and confirm it arrives at your form endpoint.
8. Repeat on a phone.

## Custom domain

Vercel project → **Settings → Domains** → add your domain, then add the DNS records Vercel shows at your domain registrar. HTTPS is set up automatically.
